// Run with: npm test   (uses Node's built-in test runner + global fetch, Node 22+)
process.env.NODE_ENV = 'test';

const { test, before, after, describe } = require('node:test');
const assert = require('node:assert/strict');
const { createApp } = require('../server');

let server, base;

before(async () => {
  const app = createApp(':memory:'); // fresh in-memory DB for the whole run
  await new Promise((resolve) => { server = app.listen(0, resolve); });
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => new Promise((resolve) => server.close(resolve)));

async function call(method, url, body) {
  const res = await fetch(base + url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, body: await res.json() };
}
const mkEvent = (over = {}) =>
  call('POST', '/api/events', { name: 'Conf', date: '2026-12-01', venue: 'Hall A', capacity: 5, ...over });
const register = (eventId, over = {}) =>
  call('POST', `/api/events/${eventId}/attendees`,
    { name: 'Ann Lee', email: 'ann@example.com', ticket_type: 'General', ...over });

describe('Events', () => {
  test('creates and lists an event', async () => {
    const created = await mkEvent({ name: 'DevFest' });
    assert.equal(created.status, 201);
    assert.equal(created.body.name, 'DevFest');
    assert.equal(created.body.attendee_count, 0);

    const list = await call('GET', '/api/events');
    assert.equal(list.status, 200);
    assert.ok(list.body.some((e) => e.id === created.body.id));
  });

  test('rejects missing required fields', async () => {
    const r = await call('POST', '/api/events', { name: '', date: '', venue: '' });
    assert.equal(r.status, 400);
    assert.match(r.body.error, /name is required/i);
    assert.match(r.body.error, /date is required/i);
    assert.match(r.body.error, /venue is required/i);
  });

  test('rejects impossible dates and bad capacity', async () => {
    assert.equal((await mkEvent({ date: '2026-02-30' })).status, 400);
    assert.equal((await mkEvent({ date: 'tomorrow' })).status, 400);
    assert.equal((await mkEvent({ capacity: 0 })).status, 400);
    assert.equal((await mkEvent({ capacity: 2.5 })).status, 400);
  });

  test('GET unknown event -> 404', async () => {
    assert.equal((await call('GET', '/api/events/99999')).status, 404);
  });

  test('delete event cascades to its attendees', async () => {
    const ev = (await mkEvent({ name: 'Cascade Test' })).body;
    const a = (await register(ev.id, { email: 'cascade@example.com' })).body;

    const del = await call('DELETE', `/api/events/${ev.id}`);
    assert.equal(del.status, 200);
    assert.equal(del.body.removedAttendees, 1);

    assert.equal((await call('GET', `/api/events/${ev.id}`)).status, 404);
    // attendee row must be gone too (FK ON DELETE CASCADE)
    assert.equal((await call('DELETE', `/api/attendees/${a.id}`)).status, 404);
  });

  test('delete unknown event -> 404', async () => {
    assert.equal((await call('DELETE', '/api/events/99999')).status, 404);
  });
});

describe('Registration validation', () => {
  test('registers an attendee and bumps the count', async () => {
    const ev = (await mkEvent({ name: 'Reg OK' })).body;
    const r = await register(ev.id);
    assert.equal(r.status, 201);
    assert.equal(r.body.event_id, ev.id);
    assert.equal((await call('GET', `/api/events/${ev.id}`)).body.attendee_count, 1);
  });

  test('required fields', async () => {
    const ev = (await mkEvent()).body;
    const r = await register(ev.id, { name: '', email: '', ticket_type: '' });
    assert.equal(r.status, 400);
    assert.match(r.body.error, /name is required/i);
    assert.match(r.body.error, /email is required/i);
    assert.match(r.body.error, /ticket type is required/i);
  });

  test('invalid email formats are rejected', async () => {
    const ev = (await mkEvent()).body;
    for (const bad of ['plainaddress', 'a@b', '@example.com', 'a b@example.com', 'a@@example.com']) {
      const r = await register(ev.id, { email: bad });
      assert.equal(r.status, 400, `expected 400 for "${bad}"`);
      assert.match(r.body.error, /email format is invalid/i);
    }
  });

  test('invalid ticket type is rejected', async () => {
    const ev = (await mkEvent()).body;
    const r = await register(ev.id, { ticket_type: 'Platinum' });
    assert.equal(r.status, 400);
  });

  test('malformed JSON body -> 400', async () => {
    const res = await fetch(`${base}/api/events`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{bad json',
    });
    assert.equal(res.status, 400);
  });
});

describe('Edge cases required by the spec', () => {
  test('registering for a NON-EXISTENT event -> 404', async () => {
    const r = await register(424242);
    assert.equal(r.status, 404);
    assert.match(r.body.error, /does not exist/i);
  });

  test('duplicate registration (same event + email) -> 409', async () => {
    const ev = (await mkEvent({ name: 'Dup Test' })).body;
    assert.equal((await register(ev.id)).status, 201);
    const dup = await register(ev.id);
    assert.equal(dup.status, 409);
    assert.match(dup.body.error, /already registered/i);
  });

  test('duplicate check is case-insensitive and ignores whitespace', async () => {
    const ev = (await mkEvent({ name: 'Dup Case' })).body;
    assert.equal((await register(ev.id, { email: 'Bob@Example.com' })).status, 201);
    assert.equal((await register(ev.id, { email: '  bob@example.COM ' })).status, 409);
  });

  test('same email CAN register for a different event', async () => {
    const e1 = (await mkEvent({ name: 'Multi 1' })).body;
    const e2 = (await mkEvent({ name: 'Multi 2' })).body;
    assert.equal((await register(e1.id, { email: 'multi@example.com' })).status, 201);
    assert.equal((await register(e2.id, { email: 'multi@example.com' })).status, 201);
  });

  test('registering for a FULL event -> 409, then succeeds after a seat frees up', async () => {
    const ev = (await mkEvent({ name: 'Tiny', capacity: 2 })).body;
    const a1 = (await register(ev.id, { email: 'f1@example.com' })).body;
    assert.equal((await register(ev.id, { email: 'f2@example.com' })).status, 201);

    const full = await register(ev.id, { email: 'f3@example.com' });
    assert.equal(full.status, 409);
    assert.match(full.body.error, /full/i);

    await call('DELETE', `/api/attendees/${a1.id}`);
    assert.equal((await register(ev.id, { email: 'f3@example.com' })).status, 201);
  });

  test('concurrent registrations never exceed capacity', async () => {
    const ev = (await mkEvent({ name: 'Race', capacity: 3 })).body;
    const results = await Promise.all(
      Array.from({ length: 10 }, (_, i) => register(ev.id, { email: `race${i}@example.com` })),
    );
    assert.equal(results.filter((r) => r.status === 201).length, 3);
    assert.equal((await call('GET', `/api/events/${ev.id}`)).body.attendee_count, 3);
  });
});

describe('Search & delete attendees', () => {
  let evA, evB;
  before(async () => {
    evA = (await mkEvent({ name: 'Search Summit' })).body;
    evB = (await mkEvent({ name: 'Other Gala' })).body;
    await register(evA.id, { name: 'Alice Johnson', email: 'alice@s.com' });
    await register(evA.id, { name: 'Alicia Keys', email: 'alicia@s.com', ticket_type: 'VIP' });
    await register(evB.id, { name: 'Bob Stone', email: 'bob@s.com', ticket_type: 'Student' });
    await register(evB.id, { name: 'Alice Johnson', email: 'alice@s.com' });
  });

  test('search by attendee name (partial, case-insensitive)', async () => {
    const r = await call('GET', '/api/attendees?name=ALIC');
    assert.equal(r.status, 200);
    const names = r.body.map((a) => a.name);
    assert.ok(names.includes('Alice Johnson') && names.includes('Alicia Keys'));
    assert.ok(!names.includes('Bob Stone'));
  });

  test('search by event name', async () => {
    const r = await call('GET', '/api/attendees?event=gala');
    assert.ok(r.body.length >= 2);
    assert.ok(r.body.every((a) => a.event_name === 'Other Gala'));
  });

  test('search by name AND event together', async () => {
    const r = await call('GET', '/api/attendees?name=alice&event=summit');
    assert.equal(r.body.length, 1);
    assert.equal(r.body[0].event_name, 'Search Summit');
  });

  test('no match -> empty array; wildcard chars are treated literally', async () => {
    assert.deepEqual((await call('GET', '/api/attendees?name=zzzznope')).body, []);
    assert.deepEqual((await call('GET', '/api/attendees?name=%25')).body, []); // "%"
  });

  test('list attendees of one event', async () => {
    const r = await call('GET', `/api/events/${evA.id}/attendees`);
    assert.equal(r.body.length, 2);
    assert.equal((await call('GET', '/api/events/99999/attendees')).status, 404);
  });

  test('delete attendee, then 404 on repeat', async () => {
    const a = (await register(evA.id, { name: 'Temp', email: 'temp@s.com' })).body;
    assert.equal((await call('DELETE', `/api/attendees/${a.id}`)).status, 200);
    assert.equal((await call('DELETE', `/api/attendees/${a.id}`)).status, 404);
  });
});

test('unknown API route -> JSON 404', async () => {
  const r = await call('GET', '/api/nope');
  assert.equal(r.status, 404);
});
