/* Event Management System - client side
 * All data flows through the REST API using fetch() + JSON.
 * The DOM is updated in place; the page never reloads.
 */

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const state = {
  events: [],
  selectedEventId: null, // when set, the attendee table is scoped to this event
};

// ---- DOM helpers -------------------------------------------------------
const $ = (id) => document.getElementById(id);

/** Create an element safely (text goes through textContent, so no XSS). */
function el(tag, { className, text, attrs = {}, on = {} } = {}, children = []) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
  for (const [evt, fn] of Object.entries(on)) node.addEventListener(evt, fn);
  children.forEach((c) => node.appendChild(c));
  return node;
}

let toastTimer;
function toast(message, type = 'success') {
  const t = $('toast');
  t.textContent = message;
  t.className = `toast show ${type}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.className = 'toast'), 3200);
}

// ---- API wrapper -------------------------------------------------------
async function api(url, options = {}) {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  let data = null;
  try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) {
    const err = new Error((data && data.error) || `Request failed (${res.status})`);
    err.status = res.status;
    throw err;
  }
  return data;
}

// ---- Rendering ---------------------------------------------------------
function formatDate(iso) {
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(y, m - 1, d).toLocaleDateString(undefined, {
    year: 'numeric', month: 'short', day: 'numeric',
  });
}

function renderEvents() {
  const list = $('events-list');
  list.replaceChildren();
  $('event-total').textContent = `${state.events.length} event${state.events.length === 1 ? '' : 's'}`;

  if (!state.events.length) {
    list.appendChild(el('p', { className: 'empty', text: 'No events yet. Add one to get started.' }));
  }

  for (const ev of state.events) {
    const full = ev.attendee_count >= ev.capacity;
    const item = el('div', {
      className: 'event-item' + (ev.id === state.selectedEventId ? ' active' : ''),
      attrs: { title: 'Click to show only this event\'s attendees' },
      on: { click: () => selectEvent(ev.id) },
    }, [
      el('div', {}, [
        el('div', { className: 'event-title', text: ev.name }),
        el('div', { className: 'event-meta', text: `${formatDate(ev.date)} · ${ev.venue}` }),
      ]),
      el('div', { className: 'event-actions' }, [
        el('span', {
          className: 'badge' + (full ? ' full' : ''),
          text: full ? `Full ${ev.attendee_count}/${ev.capacity}` : `${ev.attendee_count}/${ev.capacity} registered`,
        }),
        el('button', {
          className: 'btn danger',
          text: 'Delete',
          on: { click: (e) => { e.stopPropagation(); deleteEvent(ev); } },
        }),
      ]),
    ]);
    list.appendChild(item);
  }

  // Keep the registration dropdown in sync (preserve current selection)
  const select = $('attendee-event');
  const previous = select.value;
  select.replaceChildren();
  if (!state.events.length) {
    select.appendChild(el('option', { text: 'No events available', attrs: { value: '' } }));
  } else {
    for (const ev of state.events) {
      select.appendChild(el('option', { text: `${ev.name} (${formatDate(ev.date)})`, attrs: { value: ev.id } }));
    }
    if ([...select.options].some((o) => o.value === previous)) select.value = previous;
    else if (state.selectedEventId) select.value = String(state.selectedEventId);
  }
}

function renderAttendees(rows) {
  const body = $('attendees-body');
  body.replaceChildren();
  $('attendees-empty').hidden = rows.length > 0;
  $('attendee-total').textContent = `${rows.length} shown`;

  const scoped = state.events.find((e) => e.id === state.selectedEventId);
  $('attendees-title').textContent = scoped ? `Attendees - ${scoped.name}` : 'Attendees';

  for (const a of rows) {
    body.appendChild(el('tr', {}, [
      el('td', { text: a.name }),
      el('td', { text: a.email }),
      el('td', {}, [el('span', { className: `tag ${a.ticket_type}`, text: a.ticket_type })]),
      el('td', { text: a.event_name }),
      el('td', {}, [el('button', {
        className: 'btn danger',
        text: 'Delete',
        on: { click: () => deleteAttendee(a) },
      })]),
    ]));
  }
}

// ---- Data loading ------------------------------------------------------
async function loadEvents() {
  state.events = await api('/api/events');
  if (state.selectedEventId && !state.events.some((e) => e.id === state.selectedEventId)) {
    state.selectedEventId = null; // selected event was deleted
  }
  renderEvents();
}

/** Loads attendees using the search boxes (name + event filters). */
async function loadAttendees() {
  const name = $('search-name').value.trim();
  const eventText = $('search-event').value.trim();
  const params = new URLSearchParams();
  if (name) params.set('name', name);
  if (eventText) params.set('event', eventText);

  let rows = await api('/api/attendees?' + params.toString());
  if (state.selectedEventId) rows = rows.filter((r) => r.event_id === state.selectedEventId);
  renderAttendees(rows);
}

async function refreshAll() {
  await loadEvents();
  await loadAttendees();
}

function selectEvent(id) {
  state.selectedEventId = state.selectedEventId === id ? null : id; // click again to unselect
  $('attendee-event').value = state.selectedEventId || $('attendee-event').value;
  renderEvents();
  loadAttendees().catch((e) => toast(e.message, 'error'));
}

// ---- Actions -----------------------------------------------------------
async function deleteEvent(ev) {
  const msg = `Delete "${ev.name}"` +
    (ev.attendee_count ? ` and its ${ev.attendee_count} attendee(s)?` : '?');
  if (!confirm(msg)) return;
  try {
    await api(`/api/events/${ev.id}`, { method: 'DELETE' });
    toast('Event deleted.');
    await refreshAll();
  } catch (e) { toast(e.message, 'error'); await refreshAll().catch(() => {}); }
}

async function deleteAttendee(a) {
  if (!confirm(`Remove ${a.name} from "${a.event_name}"?`)) return;
  try {
    await api(`/api/attendees/${a.id}`, { method: 'DELETE' });
    toast('Attendee removed.');
    await refreshAll();
  } catch (e) { toast(e.message, 'error'); await refreshAll().catch(() => {}); }
}

// ---- Form handlers (client-side validation mirrors the server) --------
$('event-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const err = $('event-error');
  err.textContent = '';

  const body = {
    name: $('event-name').value.trim(),
    date: $('event-date').value,
    venue: $('event-venue').value.trim(),
    capacity: $('event-capacity').value === '' ? 100 : Number($('event-capacity').value),
  };
  if (!body.name || !body.date || !body.venue) {
    err.textContent = 'Event name, date and venue are all required.';
    return;
  }
  if (!Number.isInteger(body.capacity) || body.capacity < 1) {
    err.textContent = 'Capacity must be a whole number of at least 1.';
    return;
  }

  try {
    await api('/api/events', { method: 'POST', body });
    $('event-form').reset();
    $('event-capacity').value = 100;
    toast('Event added.');
    await refreshAll();
  } catch (ex) { err.textContent = ex.message; }
});

$('attendee-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const err = $('attendee-error');
  err.textContent = '';

  const eventId = $('attendee-event').value;
  const body = {
    name: $('attendee-name').value.trim(),
    email: $('attendee-email').value.trim(),
    ticket_type: $('attendee-ticket').value,
  };
  if (!eventId) { err.textContent = 'Please create/select an event first.'; return; }
  if (!body.name) { err.textContent = 'Name is required.'; return; }
  if (!body.email) { err.textContent = 'Email is required.'; return; }
  if (!EMAIL_RE.test(body.email)) { err.textContent = 'Please enter a valid email address.'; return; }

  try {
    await api(`/api/events/${eventId}/attendees`, { method: 'POST', body });
    $('attendee-name').value = '';
    $('attendee-email').value = '';
    toast('Attendee registered.');
    await refreshAll();
  } catch (ex) {
    err.textContent = ex.message;     // e.g. duplicate, event full, event gone
    if (ex.status === 404) await refreshAll().catch(() => {}); // event was deleted elsewhere
  }
});

// Live search (debounced) - re-renders results without a page reload
let searchTimer;
function onSearchInput() {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => loadAttendees().catch((e) => toast(e.message, 'error')), 200);
}
$('search-name').addEventListener('input', onSearchInput);
$('search-event').addEventListener('input', onSearchInput);
$('search-clear').addEventListener('click', () => {
  $('search-name').value = '';
  $('search-event').value = '';
  state.selectedEventId = null;
  renderEvents();
  loadAttendees().catch((e) => toast(e.message, 'error'));
});

// ---- Boot --------------------------------------------------------------
refreshAll().catch((e) => toast('Could not load data: ' + e.message, 'error'));
