// Uses Node's built-in SQLite module (Node 22.13+), so there is nothing to compile.
const { DatabaseSync } = require('node:sqlite');

/**
 * Opens (and initialises) the SQLite database.
 *
 * Schema: one Event has many Attendees (one-to-many).
 *   events.id  <-- attendees.event_id  (FOREIGN KEY, ON DELETE CASCADE)
 *
 * UNIQUE(event_id, email) is the database-level guard against duplicate
 * registrations; the API also checks it explicitly to return a friendly 409.
 */
function openDb(file = 'events.db') {
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;'); // SQLite ignores FKs unless this is set

  db.exec(`
    CREATE TABLE IF NOT EXISTS events (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      name       TEXT    NOT NULL,
      date       TEXT    NOT NULL,              -- ISO date: YYYY-MM-DD
      venue      TEXT    NOT NULL,
      capacity   INTEGER NOT NULL DEFAULT 100 CHECK (capacity > 0),
      created_at TEXT    NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS attendees (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      name        TEXT    NOT NULL,
      email       TEXT    NOT NULL COLLATE NOCASE,
      ticket_type TEXT    NOT NULL
                  CHECK (ticket_type IN ('General', 'VIP', 'Student')),
      event_id    INTEGER NOT NULL,
      created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
      UNIQUE (event_id, email)
    );

    CREATE INDEX IF NOT EXISTS idx_attendees_event ON attendees(event_id);
    CREATE INDEX IF NOT EXISTS idx_attendees_name  ON attendees(name);
  `);

  return db;
}

module.exports = { openDb };
