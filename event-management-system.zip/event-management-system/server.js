const path = require('path');
const express = require('express');
const { openDb } = require('./db');

const TICKET_TYPES = ['General', 'VIP', 'Student'];
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

function isValidDate(s) {
  if (!DATE_RE.test(s)) return false;
  const d = new Date(s + 'T00:00:00Z');
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
}

const clean = (v) => (typeof v === 'string' ? v.trim() : '');

/** Builds the Express app. Takes a db file so tests can use ':memory:'. */
function createApp(dbFile = process.env.DB_PATH || 'events.db') {
  const db = openDb(dbFile);
  const app = express();

  // ---- Middleware ------------------------------------------------------
  app.use(express.json());                                   // parse JSON bodies
  app.use(express.static(path.join(__dirname, 'public')));   // serve frontend
  app.use('/api', (req, _res, next) => {                     // simple request log
    if (process.env.NODE_ENV !== 'test') {
      console.log(`${new Date().toISOString()} ${req.method} ${req.originalUrl}`);
    }
    next();
  });

  // ---- Prepared statements --------------------------------------------
  const q = {
    listEvents: db.prepare(`
      SELECT e.*, COUNT(a.id) AS attendee_count
      FROM events e LEFT JOIN attendees a ON a.event_id = e.id
      GROUP BY e.id ORDER BY e.date ASC, e.id ASC`),
    getEvent: db.prepare(`
      SELECT e.*, (SELECT COUNT(*) FROM attendees WHERE event_id = e.id) AS attendee_count
      FROM events e WHERE e.id = ?`),
    insertEvent: db.prepare(
      'INSERT INTO events (name, date, venue, capacity) VALUES (?, ?, ?, ?)'),
    deleteEvent: db.prepare('DELETE FROM events WHERE id = ?'),

    attendeesOfEvent: db.prepare(`
      SELECT a.*, e.name AS event_name FROM attendees a
      JOIN events e ON e.id = a.event_id
      WHERE a.event_id = ? ORDER BY a.name COLLATE NOCASE`),
    getAttendee: db.prepare('SELECT * FROM attendees WHERE id = ?'),
    findDuplicate: db.prepare(
      'SELECT id FROM attendees WHERE event_id = ? AND email = ?'),
    insertAttendee: db.prepare(
      'INSERT INTO attendees (name, email, ticket_type, event_id) VALUES (?, ?, ?, ?)'),
    deleteAttendee: db.prepare('DELETE FROM attendees WHERE id = ?'),

    // name/event filters are both optional; LIKE is case-insensitive for ASCII
    search: db.prepare(`
      SELECT a.*, e.name AS event_name, e.date AS event_date
      FROM attendees a JOIN events e ON e.id = a.event_id
      WHERE a.name LIKE @name ESCAPE '\\'
        AND e.name LIKE @event ESCAPE '\\'
      ORDER BY e.date, a.name COLLATE NOCASE`),
  };

  const like = (s) => '%' + s.replace(/[\\%_]/g, (c) => '\\' + c) + '%';

  // ---- Events ----------------------------------------------------------

  // CREATE event
  app.post('/api/events', (req, res) => {
    const name = clean(req.body.name);
    const date = clean(req.body.date);
    const venue = clean(req.body.venue);
    const capacity = req.body.capacity === undefined || req.body.capacity === ''
      ? 100 : Number(req.body.capacity);

    const errors = [];
    if (!name) errors.push('Event name is required.');
    if (!date) errors.push('Event date is required.');
    else if (!isValidDate(date)) errors.push('Date must be a valid date (YYYY-MM-DD).');
    if (!venue) errors.push('Venue is required.');
    if (!Number.isInteger(capacity) || capacity < 1 || capacity > 100000) {
      errors.push('Capacity must be a whole number between 1 and 100000.');
    }
    if (errors.length) return res.status(400).json({ error: errors.join(' '), errors });

    const info = q.insertEvent.run(name, date, venue, capacity);
    res.status(201).json(q.getEvent.get(Number(info.lastInsertRowid)));
  });

  // READ all events (with attendee counts)
  app.get('/api/events', (_req, res) => res.json(q.listEvents.all()));

  // READ one event
  app.get('/api/events/:id', (req, res) => {
    const ev = q.getEvent.get(Number(req.params.id));
    if (!ev) return res.status(404).json({ error: 'Event not found.' });
    res.json(ev);
  });

  // DELETE event (attendees are removed by ON DELETE CASCADE)
  app.delete('/api/events/:id', (req, res) => {
    const id = Number(req.params.id);
    const ev = q.getEvent.get(id);
    if (!ev) return res.status(404).json({ error: 'Event not found.' });
    q.deleteEvent.run(id);
    res.json({ message: 'Event deleted.', removedAttendees: ev.attendee_count });
  });

  // ---- Attendees -------------------------------------------------------

  // READ attendees of one event
  app.get('/api/events/:id/attendees', (req, res) => {
    const id = Number(req.params.id);
    if (!q.getEvent.get(id)) return res.status(404).json({ error: 'Event not found.' });
    res.json(q.attendeesOfEvent.all(id));
  });

  // REGISTER an attendee to an event
  app.post('/api/events/:id/attendees', (req, res) => {
    const eventId = Number(req.params.id);
    const name = clean(req.body.name);
    const email = clean(req.body.email).toLowerCase();
    const ticketType = clean(req.body.ticket_type);

    const errors = [];
    if (!name) errors.push('Attendee name is required.');
    if (!email) errors.push('Email is required.');
    else if (!EMAIL_RE.test(email)) errors.push('Email format is invalid.');
    if (!ticketType) errors.push('Ticket type is required.');
    else if (!TICKET_TYPES.includes(ticketType)) {
      errors.push(`Ticket type must be one of: ${TICKET_TYPES.join(', ')}.`);
    }
    if (errors.length) return res.status(400).json({ error: errors.join(' '), errors });

    const ev = q.getEvent.get(eventId);
    if (!ev) return res.status(404).json({ error: 'Event does not exist.' });

    if (q.findDuplicate.get(eventId, email)) {
      return res.status(409).json({ error: 'This email is already registered for this event.' });
    }
    if (ev.attendee_count >= ev.capacity) {
      return res.status(409).json({ error: `Event is full (capacity ${ev.capacity}).` });
    }

    // Capacity check + insert in one transaction so a request can't oversell.
    let newId;
    try {
      db.exec('BEGIN IMMEDIATE');
      const fresh = q.getEvent.get(eventId);
      if (fresh.attendee_count >= fresh.capacity) {
        db.exec('ROLLBACK');
        newId = null;
      } else {
        newId = q.insertAttendee.run(name, email, ticketType, eventId).lastInsertRowid;
        db.exec('COMMIT');
      }
    } catch (err) {
      try { db.exec('ROLLBACK'); } catch { /* no open transaction */ }
      // 1555 = PRIMARYKEY, 2067 = UNIQUE constraint failure
      if (/UNIQUE constraint failed/i.test(String(err.message))) {
        return res.status(409).json({ error: 'This email is already registered for this event.' });
      }
      throw err;
    }
    if (newId === null) {
      return res.status(409).json({ error: `Event is full (capacity ${ev.capacity}).` });
    }
    res.status(201).json(q.getAttendee.get(Number(newId)));
  });

  // SEARCH attendees by name and/or event name: /api/attendees?name=ali&event=conf
  app.get('/api/attendees', (req, res) => {
    const name = clean(req.query.name);
    const event = clean(req.query.event);
    res.json(q.search.all({ name: like(name), event: like(event) }));
  });

  // DELETE attendee
  app.delete('/api/attendees/:id', (req, res) => {
    const id = Number(req.params.id);
    if (!q.getAttendee.get(id)) return res.status(404).json({ error: 'Attendee not found.' });
    q.deleteAttendee.run(id);
    res.json({ message: 'Attendee deleted.' });
  });

  // ---- Error handling --------------------------------------------------
  app.use('/api', (_req, res) => res.status(404).json({ error: 'Unknown API route.' }));

  // eslint-disable-next-line no-unused-vars
  app.use((err, _req, res, _next) => {
    if (err.type === 'entity.parse.failed') {
      return res.status(400).json({ error: 'Request body is not valid JSON.' });
    }
    console.error(err);
    res.status(500).json({ error: 'Internal server error.' });
  });

  app.locals.db = db;
  return app;
}

module.exports = { createApp };

if (require.main === module) {
  const PORT = process.env.PORT || 3000;
  createApp().listen(PORT, () => {
    console.log(`Event Management System running at http://localhost:${PORT}`);
  });
}
