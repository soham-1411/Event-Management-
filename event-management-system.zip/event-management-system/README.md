# Event Management System

A full-stack CRUD web app for managing events and their attendees.

- **Frontend:** HTML, CSS, vanilla JavaScript (`fetch` + JSON, no page reloads)
- **Backend:** Node.js + Express.js REST API
- **Database:** SQLite (Node's built-in `node:sqlite`, no native compile step)

## Quick start

```bash
# Requires Node.js 22.13 or newer
npm install
npm start          # http://localhost:3000
npm test           # 24 automated API tests
```

Optional environment variables: `PORT` (default `3000`), `DB_PATH` (default `events.db`).

## Project structure

```
event-management-system/
├── server.js          Express app: middleware, routes, validation, error handling
├── db.js              SQLite connection + schema
├── public/
│   ├── index.html     UI layout
│   ├── style.css      Styling
│   └── app.js         Fetch calls + dynamic DOM rendering
└── test/
    └── api.test.js    Automated tests (node:test)
```

## Database schema (one-to-many)

```
events (1) ───────< (many) attendees

events                         attendees
──────                         ─────────
id           PK                id           PK
name         NOT NULL          name         NOT NULL
date         NOT NULL          email        NOT NULL (case-insensitive)
venue        NOT NULL          ticket_type  CHECK IN (General, VIP, Student)
capacity     DEFAULT 100       event_id     FK -> events.id ON DELETE CASCADE
created_at                     created_at
                               UNIQUE (event_id, email)
```

Deleting an event automatically deletes its attendees (`ON DELETE CASCADE`).
The `UNIQUE (event_id, email)` constraint prevents duplicate registrations at the
database level, in addition to the explicit check in the API.

## REST API

| Method | Endpoint | Purpose | Success | Errors |
|--------|----------|---------|---------|--------|
| POST | `/api/events` | Add an event | 201 | 400 |
| GET | `/api/events` | List events (with `attendee_count`) | 200 | |
| GET | `/api/events/:id` | Get one event | 200 | 404 |
| DELETE | `/api/events/:id` | Delete event + its attendees | 200 | 404 |
| GET | `/api/events/:id/attendees` | List an event's attendees | 200 | 404 |
| POST | `/api/events/:id/attendees` | Register an attendee | 201 | 400, 404, 409 |
| GET | `/api/attendees?name=&event=` | Search by attendee and/or event name | 200 | |
| DELETE | `/api/attendees/:id` | Delete an attendee | 200 | 404 |

### Example requests

```bash
# Add an event
curl -X POST localhost:3000/api/events -H "Content-Type: application/json" \
  -d '{"name":"DevFest","date":"2026-11-15","venue":"Main Hall","capacity":100}'

# Register an attendee to event 1
curl -X POST localhost:3000/api/events/1/attendees -H "Content-Type: application/json" \
  -d '{"name":"Jane Doe","email":"jane@example.com","ticket_type":"VIP"}'

# Search
curl "localhost:3000/api/attendees?name=jane&event=dev"
```

### Validation and status codes

| Situation | Response |
|-----------|----------|
| Missing required field / bad email / bad date / bad ticket type / bad capacity | `400` with a message |
| Event does not exist (register, view, delete) | `404` |
| Same email already registered for that event (case-insensitive) | `409` |
| Event is at capacity | `409` |
| Malformed JSON body | `400` |

Capacity check and insert run inside a single SQLite transaction, so concurrent
registrations cannot oversell an event (covered by a test).

## What the tests cover

- Event creation, listing, required-field and date/capacity validation
- Cascade delete of attendees when an event is deleted
- Attendee registration, required fields, invalid email formats, invalid ticket type
- **Registering for a non-existent event** (404)
- **Duplicate registration**, including case/whitespace variants (409)
- Same email allowed in a different event
- **Registering for a full event** (409), and success again after a seat frees up
- 10 concurrent requests against a 3-seat event: exactly 3 succeed
- Search by name, by event, by both, no results, and literal handling of `%`
- Deleting attendees and events, repeat-delete returns 404

## Frontend features

- Add events and register attendees via forms (client-side validation mirrors the server)
- Live, debounced search by attendee name and/or event name
- Click an event to scope the attendee table to it (click again to clear)
- Capacity badges (`Full 2/2` highlighted), toast notifications, confirm-before-delete
- All output is inserted with `textContent`, so user-entered text cannot inject HTML

## Ideas for extension

Edit events/attendees (PUT), pagination, authentication, MongoDB variant, CSV export.
